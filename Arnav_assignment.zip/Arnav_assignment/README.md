The code is designed for Python 3.
The code needs to take in input from the input foler and ouputs it to output folder. 
Run python ratingPredictMain.py
The submission.csv is the final output.